import SwiftUI
import WebKit

struct FunTubeTheme: Identifiable {
    let id: String
    let accent: Color
    static let all: [FunTubeTheme] = [
        .init(id: "Mint", accent: Color(red: 0.43, green: 0.91, blue: 0.80)),
        .init(id: "Violet", accent: Color(red: 0.77, green: 0.63, blue: 1)),
        .init(id: "Ocean", accent: .cyan), .init(id: "Rose", accent: .pink),
        .init(id: "Amber", accent: .orange), .init(id: "Forest", accent: .green)
    ]
}

@MainActor
struct FunTubeView: View {
    @ObservedObject var browser: FunTubeBrowser
    @AppStorage("theme") private var theme = "Mint"
    @State private var query = ""
    @State private var showSettings = false
    private var accent: Color { FunTubeTheme.all.first { $0.id == theme }?.accent ?? .mint }

    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 12) {
                Image(systemName: "play.rectangle.fill").font(.title2).foregroundStyle(accent)
                Text("FunTube").font(.title3.bold())
                Spacer()
                Image(systemName: browser.protectionReady ? "checkmark.shield.fill" : "shield.slash")
                    .foregroundStyle(browser.protectionReady ? accent : .secondary)
                    .accessibilityLabel(browser.protectionReady ? "Protection ready" : "Protection not ready")
                Button { showSettings = true } label: { Image(systemName: "slider.horizontal.3").frame(width: 38, height: 38) }
                    .accessibilityLabel("Settings")
            }.padding(.horizontal, 18).padding(.vertical, 8)
            HStack {
                Image(systemName: "magnifyingglass").foregroundStyle(.secondary)
                TextField("Search YouTube or paste a link", text: $query)
                    .textInputAutocapitalization(.never).autocorrectionDisabled()
                    .submitLabel(.search).onSubmit { browser.search(query); query = "" }
                if !query.isEmpty { Button { query = "" } label: { Image(systemName: "xmark.circle.fill") }.accessibilityLabel("Clear search") }
            }.padding(12).background(.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 14)).padding(.horizontal, 14).padding(.bottom, 10)
            if browser.loading { ProgressView(value: browser.progress).tint(accent) }
            if let error = browser.errorMessage {
                VStack(spacing: 10) {
                    Image(systemName: "wifi.exclamationmark").font(.title)
                    Text(error).multilineTextAlignment(.center)
                    Button("Try again") { browser.retry() }.buttonStyle(.borderedProminent)
                }.padding().frame(maxWidth: .infinity)
            }
            BrowserSurface(webView: browser.webView).frame(maxWidth: .infinity, maxHeight: .infinity)
            HStack {
                Button { browser.back() } label: { Image(systemName: "chevron.left").frame(maxWidth: .infinity) }.disabled(!browser.canGoBack).accessibilityLabel("Back")
                Button { browser.home() } label: { Image(systemName: "house.fill").frame(maxWidth: .infinity) }.accessibilityLabel("Home")
                Button { browser.reload() } label: { Image(systemName: "arrow.clockwise").frame(maxWidth: .infinity) }.accessibilityLabel("Reload")
                Button { browser.forward() } label: { Image(systemName: "chevron.right").frame(maxWidth: .infinity) }.disabled(!browser.canGoForward).accessibilityLabel("Forward")
            }.font(.title3).padding(.vertical, 16)
        }
        .background(Color(red: 0.045, green: 0.07, blue: 0.09))
        .foregroundStyle(.white).tint(accent).preferredColorScheme(.dark)
        .sheet(isPresented: $showSettings) {
            NavigationStack {
                Form {
                    Section("Make it yours") {
                        Picker("Theme", selection: $theme) { ForEach(FunTubeTheme.all) { Text($0.id).tag($0.id) } }
                        Toggle("Auto fullscreen", isOn: $browser.autoFullscreen)
                        Text("Auto fullscreen depends on iPhone playback permissions. The player's fullscreen control is always available.").font(.caption)
                    }
                    Section("Built-in protection") {
                        Toggle("Block ads inside FunTube", isOn: $browser.protectionEnabled)
                        Text(browser.protectionStatus)
                        Text("No Safari extension or separate blocker is needed. Filtering applies inside FunTube; YouTube changes can affect it.").font(.caption)
                    }
                    Section("Activity") {
                        LabeledContent("Player ad entries removed", value: String(browser.placementsRemoved))
                        LabeledContent("Confirmed auto-skips", value: String(browser.confirmedSkips))
                        Text("These count player-data entries and confirmed dismissals, not individual ad impressions or blocked network requests.").font(.caption)
                    }
                    Section("Your account") {
                        Button("Open Google's sign-in page") { showSettings = false; browser.signIn() }
                        Text("Google may restrict sign-in inside embedded browsers. Existing Google login support has not been verified on an iPhone.").font(.caption)
                    }
                    Section("Free installation") {
                        Text("Apple's free signature lasts seven days. Keep automatic refresh enabled in Sideloadly and reconnect your phone to the PC regularly.")
                        Text("FunTube 0.1.0 · Independent app").font(.caption)
                    }
                }.navigationTitle("Your FunTube").toolbar { Button("Done") { showSettings = false } }
            }.preferredColorScheme(.dark).tint(accent)
        }
        .confirmationDialog("Open this link in Safari?", isPresented: $browser.showExternalLink, titleVisibility: .visible) {
            Button("Open Safari") { browser.openExternalLink() }
            Button("Cancel", role: .cancel) { browser.externalURL = nil }
        } message: { Text("FunTube's built-in blocker applies only inside this app.") }
    }
}

@MainActor
private struct BrowserSurface: UIViewRepresentable {
    let webView: WKWebView
    func makeUIView(context: Context) -> WKWebView { webView }
    func updateUIView(_ uiView: WKWebView, context: Context) {}
}
