import Combine
import Foundation
import SwiftUI
import UIKit
import WebKit

@MainActor
final class FunTubeBrowser: NSObject, ObservableObject, WKNavigationDelegate, WKUIDelegate, WKScriptMessageHandler {
    let webView: WKWebView
    @Published var loading = false
    @Published var progress = 0.0
    @Published var canGoBack = false
    @Published var canGoForward = false
    @Published var protectionReady = false
    @Published var protectionStatus = "Preparing built-in filtering…"
    @Published var errorMessage: String?
    @Published var showExternalLink = false
    @Published var placementsRemoved = UserDefaults.standard.integer(forKey: "placementsRemoved")
    @Published var confirmedSkips = UserDefaults.standard.integer(forKey: "confirmedSkips")
    @Published var protectionEnabled: Bool {
        didSet {
            guard oldValue != protectionEnabled else { return }
            UserDefaults.standard.set(protectionEnabled, forKey: "protectionEnabled")
            applyPreferences()
        }
    }
    @Published var autoFullscreen: Bool {
        didSet {
            UserDefaults.standard.set(autoFullscreen, forKey: "autoFullscreen")
            applyPreferences()
        }
    }
    var externalURL: URL?
    private var rules: WKContentRuleList?
    private var observations: [NSKeyValueObservation] = []
    private var prepared = false
    private var scriptReady = false
    private var pendingURL = URL(string: "https://m.youtube.com/")!

    override init() {
        protectionEnabled = UserDefaults.standard.object(forKey: "protectionEnabled") as? Bool ?? true
        autoFullscreen = UserDefaults.standard.bool(forKey: "autoFullscreen")
        let configuration = WKWebViewConfiguration()
        configuration.websiteDataStore = .default()
        configuration.allowsInlineMediaPlayback = true
        configuration.allowsAirPlayForMediaPlayback = true
        configuration.allowsPictureInPictureMediaPlayback = true
        // Keep normal iPhone user-gesture requirements. No autoplay or fake clicks
        // on account pages; video fullscreen uses WebKit's real media controls.
        configuration.applicationNameForUserAgent = "FunTube/0.1.0"
        webView = WKWebView(frame: .zero, configuration: configuration)
        super.init()
        webView.navigationDelegate = self
        webView.uiDelegate = self
        webView.allowsBackForwardNavigationGestures = true
        webView.isOpaque = false
        webView.backgroundColor = .black
        configuration.userContentController.add(WeakScriptHandler(self), name: "funTube")
        observations = [
            webView.observe(\.estimatedProgress, options: [.new]) { [weak self] view, _ in
                Task { @MainActor [weak self] in self?.progress = view.estimatedProgress }
            },
            webView.observe(\.canGoBack, options: [.new]) { [weak self] view, _ in
                Task { @MainActor [weak self] in self?.canGoBack = view.canGoBack }
            },
            webView.observe(\.canGoForward, options: [.new]) { [weak self] view, _ in
                Task { @MainActor [weak self] in self?.canGoForward = view.canGoForward }
            }
        ]
        Task { await prepare() }
    }

    private func preferencesScript() -> String {
        "window.__funTubePreferences={enabled:\(protectionEnabled),autoFullscreen:\(autoFullscreen)};"
    }

    private func installScripts() throws {
        let controller = webView.configuration.userContentController
        controller.removeAllUserScripts()
        var script = preferencesScript()
        for name in ["ad-skipper", "player-filter"] {
            guard let url = Bundle.main.url(forResource: name, withExtension: "js") else {
                throw NSError(domain: "FunTube", code: 1, userInfo: [NSLocalizedDescriptionKey: "Built-in player filters are missing."])
            }
            script += "\n" + (try String(contentsOf: url, encoding: .utf8))
        }
        controller.addUserScript(WKUserScript(source: script, injectionTime: .atDocumentStart, forMainFrameOnly: true))
    }

    private func prepare() async {
        loading = true
        do {
            try installScripts()
            guard let url = Bundle.main.url(forResource: "blocker-rules", withExtension: "json") else {
                throw NSError(domain: "FunTube", code: 2, userInfo: [NSLocalizedDescriptionKey: "Built-in network filters are missing."])
            }
            let source = try String(contentsOf: url, encoding: .utf8)
            rules = try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<WKContentRuleList, Error>) in
                WKContentRuleListStore.default().compileContentRuleList(forIdentifier: "funtube-mobile-0.1.0", encodedContentRuleList: source) { list, error in
                    if let list { continuation.resume(returning: list) }
                    else { continuation.resume(throwing: error ?? NSError(domain: "FunTube", code: 3, userInfo: [NSLocalizedDescriptionKey: "Built-in filters could not start."])) }
                }
            }
            prepared = true
            errorMessage = nil
            applyPreferences()
            webView.load(URLRequest(url: pendingURL))
        } catch {
            loading = false
            protectionStatus = "Filtering could not start."
            errorMessage = error.localizedDescription
            // Do not silently open an unfiltered page when startup fails.
        }
    }

    private func applyPreferences() {
        guard prepared else { return }
        let controller = webView.configuration.userContentController
        controller.removeAllContentRuleLists()
        if protectionEnabled, let rules { controller.add(rules) }
        do { try installScripts() } catch { errorMessage = error.localizedDescription }
        let settings = "window.__funTube?.configure({enabled:\(protectionEnabled),autoFullscreen:\(autoFullscreen)});"
        webView.evaluateJavaScript(settings, completionHandler: nil)
        protectionReady = protectionEnabled && rules != nil && scriptReady
        protectionStatus = !protectionEnabled ? "Protection is off." : (scriptReady ? "Built-in player and network filters are active." : "Network filters ready. Waiting for YouTube's player filters…")
    }

    private func navigate(_ url: URL) {
        pendingURL = url
        errorMessage = nil
        if prepared { webView.load(URLRequest(url: url)) }
    }

    func search(_ input: String) {
        let value = input.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !value.isEmpty else { return }
        let candidate = value.hasPrefix("youtu.be/") || value.hasPrefix("m.youtube.com/") || value.hasPrefix("www.youtube.com/") ? "https://" + value : value
        if let url = URL(string: candidate), url.scheme == "https", let host = url.host?.lowercased(), host == "youtu.be" || host == "youtube.com" || host.hasSuffix(".youtube.com") {
            navigate(url)
            return
        }
        var url = URLComponents(string: "https://m.youtube.com/results")!
        url.queryItems = [URLQueryItem(name: "search_query", value: value)]
        if let result = url.url { navigate(result) }
    }

    func home() { navigate(URL(string: "https://m.youtube.com/")!) }
    func reload() { if prepared { errorMessage = nil; webView.reload() } }
    func retry() { if prepared { navigate(pendingURL) } else { Task { await prepare() } } }
    func back() { if webView.canGoBack { webView.goBack() } }
    func forward() { if webView.canGoForward { webView.goForward() } }
    func signIn() { navigate(URL(string: "https://accounts.google.com/ServiceLogin?service=youtube&continue=https%3A%2F%2Fm.youtube.com%2F")!) }
    func openExternalLink() { if let externalURL { UIApplication.shared.open(externalURL) }; externalURL = nil }

    private func isInternal(_ url: URL) -> Bool {
        guard url.scheme == "https", let host = url.host?.lowercased() else { return false }
        return host == "youtube.com" || host.hasSuffix(".youtube.com") || host == "youtu.be" || ["accounts.google.com", "consent.google.com"].contains(host)
    }

    func webView(_ webView: WKWebView, decidePolicyFor action: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard let url = action.request.url else { decisionHandler(.cancel); return }
        if action.targetFrame?.isMainFrame == false { decisionHandler(.allow); return }
        if isInternal(url) { pendingURL = url; decisionHandler(.allow) }
        else {
            decisionHandler(.cancel)
            if url.scheme == "https", action.navigationType == .linkActivated { externalURL = url; showExternalLink = true }
        }
    }

    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration, for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        if navigationAction.targetFrame == nil, let url = navigationAction.request.url {
            if isInternal(url) { navigate(url) }
            else if url.scheme == "https" { externalURL = url; showExternalLink = true }
        }
        return nil
    }

    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
        loading = true; errorMessage = nil; scriptReady = false; protectionReady = false
    }
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) { loading = false; applyPreferences() }
    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) { failed(error) }
    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) { failed(error) }
    func webViewWebContentProcessDidTerminate(_ webView: WKWebView) { loading = false; errorMessage = "The page stopped. Tap Try again to reopen it." }
    private func failed(_ error: Error) {
        guard (error as NSError).code != NSURLErrorCancelled else { return }
        loading = false; errorMessage = "Could not load this page. Check your connection and try again."
    }

    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        guard message.frameInfo.isMainFrame,
              let url = message.frameInfo.request.url, let host = url.host?.lowercased(),
              host == "youtube.com" || host.hasSuffix(".youtube.com"),
              let payload = message.body as? [String: Any], let type = payload["type"] as? String else { return }
        if type == "ready" { scriptReady = true; applyPreferences(); return }
        guard protectionEnabled, let count = payload["count"] as? Int, (1...1000).contains(count) else { return }
        if type == "placements" { placementsRemoved += count; UserDefaults.standard.set(placementsRemoved, forKey: "placementsRemoved") }
        if type == "skips", count == 1 { confirmedSkips += 1; UserDefaults.standard.set(confirmedSkips, forKey: "confirmedSkips") }
    }
}

@MainActor
private final class WeakScriptHandler: NSObject, WKScriptMessageHandler {
    weak var target: FunTubeBrowser?
    init(_ target: FunTubeBrowser) { self.target = target }
    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        target?.userContentController(userContentController, didReceive: message)
    }
}
