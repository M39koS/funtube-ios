// Isolated-world media handling. Only recognized in-player ad controls
// count as evidence; ordinary video buttons and text are never clicked.
globalThis.createFunTubeAdSkipper=function({onEpisode=()=>{},onStatus=()=>{},onSkipped=()=>{}}={}) {
  const skipSelector='.ytp-ad-skip-button,.ytp-ad-skip-button-modern,.ytp-skip-ad-button,.ytp-ad-skip-button-container button,.ytp-ad-skip-button-slot button,.videoAdUiSkipButton,button[id^="skip-button:"],button[aria-label="Skip ad"],button[aria-label="Skip Ad"],.ytp-ad-skip-button-container[role="button"]';
  const evidenceSelector='.ytp-ad-preview-container,.ytp-ad-duration-remaining,.ytp-ad-text,.ytp-ad-player-overlay-instream-info,.ytp-ad-persistent-progress-bar-container';
  const actionSelector='button,[role="button"],input[type="button"],input[type="submit"]';
  let previous=null,active=false,lastPageTry=0,cardVideo=null,pendingSkip=null;
  const clicked=new WeakMap();
  function visible(el) {
    if(!el?.isConnected||!el.getClientRects().length||el.closest('[hidden],[aria-hidden="true"]'))return false;
    const style=getComputedStyle(el);
    return style.display!=='none'&&style.visibility!=='hidden'&&Number(style.opacity)!==0;
  }
  function all(root,selector) {
    const found=[...root.querySelectorAll(selector)];
    for(const el of root.querySelectorAll('*'))if(el.shadowRoot)found.push(...all(el.shadowRoot,selector));
    return found;
  }
  function restoreMedia() {
    if(previous){try{previous.video.muted=previous.muted;previous.video.playbackRate=previous.rate;}catch{}previous=null;}
  }
  function restore() {
    pendingSkip=null;
    restoreMedia();
    if(active){active=false;onStatus('');}
  }
  function label(el){return (el.innerText||el.textContent||el.value||'').replace(/\s+/g,' ').trim();}
  function skipLabel(el){const copy=el.cloneNode(true);for(const icon of copy.querySelectorAll('svg,yt-icon,[aria-hidden="true"]'))icon.remove();return label(copy);}
  function context(p){
    // Discover shadow roots once, then reuse them across selectors.
    const roots=[p];
    for(let i=0;i<roots.length;i++)for(const el of roots[i].querySelectorAll('*'))if(el.shadowRoot)roots.push(el.shadowRoot);
    const select=selector=>roots.flatMap(root=>[...root.querySelectorAll(selector)]);
    const marked=p.classList.contains('ad-showing')||p.classList.contains('ad-interrupting');
    const known=select(skipSelector).filter(visible);
    const evidence=select(evidenceSelector).some(visible);
    // Static sponsored cards have a plain Skip action rather than the legacy
    // ad button classes. Require both the disclosure and an advertiser CTA
    // inside this player; never infer ads from ordinary page text alone.
    const disclosure=select('span,div,p,small,a').some(el=>/^sponsored(?:\s*[ⓘℹ])?$/i.test((el.textContent||'').trim())&&visible(el));
    const advertiserAction=disclosure&&select('button,[role="button"],a').some(el=>/^(shop now|learn more|visit site|visit website|buy now)$/i.test((el.textContent||'').trim())&&visible(el));
    const card=!!advertiserAction;
    const generic=marked||evidence||disclosure?select(actionSelector).filter(el=>visible(el)&&(/^(skip|skip ad)$/i.test(skipLabel(el))||/^(skip|skip ad)$/i.test(el.getAttribute('aria-label')||''))):[];
    const disclosedSkip=disclosure&&generic.length>0;
    return {ad:marked||known.length>0||evidence||card||disclosedSkip,card:card||disclosedSkip,buttons:[...new Set([...known,...generic])]};
  }
  function activate(button,gesture){
    if(gesture){
      const box=button.getBoundingClientRect();
      const options={bubbles:true,composed:true,cancelable:true,clientX:box.x+box.width/2,clientY:box.y+box.height/2,button:0,pointerId:1,pointerType:'mouse',isPrimary:true};
      // Some custom controls listen for a pointer gesture instead of click.
      // Use this only when the initial click left the same ad control visible.
      for(const [type,buttons] of [['pointerdown',1],['mousedown',1],['pointerup',0],['mouseup',0]]){
        if(!visible(button))return;
        button.dispatchEvent(type.startsWith('pointer')?new PointerEvent(type,{...options,buttons}):new MouseEvent(type,{...options,buttons}));
      }
    }
    if(visible(button))button.click();
  }
  function tick() {
    function confirmSkip(){if(!pendingSkip)return;const state=context(pendingSkip.player);if(performance.now()-pendingSkip.time>2000){pendingSkip=null;return;}if(!visible(pendingSkip.button)&&(!state.ad||(pendingSkip.card&&!state.card))){pendingSkip=null;onSkipped();}}
    confirmSkip();
    const p=document.querySelector('#movie_player')||document.querySelector('.html5-video-player');
    if(!p){cardVideo=null;restore();return;}
    const {buttons,ad,card}=context(p);
    if(!ad){cardVideo=null;restore();return;}
    const playerVideo=p.querySelector('video')||all(p,'video')[0];
    if(card)cardVideo=playerVideo||null;
    const uiOnly=card||!!(cardVideo&&cardVideo===playerVideo);
    if(!active){active=true;onEpisode();}
    const now=performance.now();
    let clickedSkip=false;
    // Skip controls can appear before YouTube sets the ad-showing class.
    for(const b of buttons){
      const attempt=clicked.get(b);
      if(b.disabled||b.getAttribute('aria-disabled')==='true'||now-(attempt?.time??-1000)<300)continue;
      clicked.set(b,{time:now});pendingSkip={button:b,player:p,card,time:now};activate(b,!!attempt);clickedSkip=true;confirmSkip();
    }
    if(!uiOnly&&now-lastPageTry>500){lastPageTry=now;document.dispatchEvent(new Event('funtube-try-player-skip'));}
    // Re-check after a synchronous click so a newly resumed video is untouched.
    const after=clickedSkip?context(p):{ad,card};
    if(!after.ad){cardVideo=null;restore();return;}
    // A sponsored image/pause card overlays the original video. Dismiss it
    // through its Skip control without seeking or accelerating that video.
    if(uiOnly||after.card){restoreMedia();onStatus(clickedSkip?'Closing sponsored ad':'Waiting for sponsored ad Skip to unlock');return;}
    const v=p.querySelector('video')||all(p,'video')[0];
    if(!v){onStatus('Waiting for ad player');return;}
    if(previous&&previous.video!==v){try{previous.video.muted=previous.muted;previous.video.playbackRate=previous.rate;}catch{}previous=null;}
    if(!previous)previous={video:v,muted:v.muted,rate:v.playbackRate};
    try{v.muted=true;}catch{}
    // Seeking almost to the end can strand YouTube's ad timer at 14/15.
    // Let the ad reach its real ended event at normal speed and click Skip
    // whenever it becomes available. Restore the user's speed afterward.
    try{if(v.playbackRate!==1)v.playbackRate=1;}catch{}
    onStatus(clickedSkip?'Skipping ad':buttons.length?'Waiting for Skip to unlock':'Ad muted · auto-skip active');
  }
  return {tick,restore};
};
