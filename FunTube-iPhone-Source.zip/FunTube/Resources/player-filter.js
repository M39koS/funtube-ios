// FunTube's in-app player filtering. No browser extension or remote proxy.
// MIT. Limited to YouTube documents; never touches Google sign-in pages.
(() => {
  'use strict';
  if (!/(^|\.)youtube\.com$/.test(location.hostname) || window.__funTubePlayerFilter) return;
  window.__funTubePlayerFilter = true;
  const state = { enabled: window.__funTubePreferences?.enabled !== false, autoFullscreen: window.__funTubePreferences?.autoFullscreen === true };
  const adKeys = new Set(['adPlacements', 'playerAds', 'adSlots', 'adBreakHeartbeatParams']);
  const originalParse = JSON.parse;
  function notify(type, count = 1) {
    try { window.webkit?.messageHandlers?.funTube?.postMessage({ type, count }); } catch {}
  }
  function prune(value) {
    if (!state.enabled || !value || typeof value !== 'object') return value;
    // The input is freshly parsed JSON, so there are no accessors or cycles.
    // A node budget bounds work on unusually large API responses.
    const pending = [value]; let budget = 30000, removed = 0;
    while (pending.length && budget-- > 0) {
      const current = pending.pop();
      for (const key of Object.keys(current)) {
        const child = current[key];
        if (adKeys.has(key)) {
          removed += Array.isArray(child) ? child.length : (child ? 1 : 0);
          delete current[key];
        } else if (child && typeof child === 'object') pending.push(child);
      }
    }
    if (removed) notify('placements', Math.min(removed, 1000));
    return value;
  }
  function parsedPlayerData(value) {
    // Do not walk unrelated JSON used elsewhere in the page.
    if (value?.playabilityStatus || value?.videoDetails || value?.streamingData || value?.playerResponse) return prune(value);
    return value;
  }
  JSON.parse = function(text, reviver) {
    const result = originalParse.call(JSON, text, reviver);
    return reviver === undefined && typeof text === 'string' && /"(?:adPlacements|playerAds|adSlots)"\s*:/.test(text) ? parsedPlayerData(result) : result;
  };
  const descriptor = Object.getOwnPropertyDescriptor(window, 'ytInitialPlayerResponse');
  if (!descriptor || (descriptor.configurable && !descriptor.get && !descriptor.set)) {
    let value = descriptor?.value;
    Object.defineProperty(window, 'ytInitialPlayerResponse', { configurable: true, enumerable: true,
      get: () => value, set: next => { value = parsedPlayerData(next); } });
    if (value) value = parsedPlayerData(value);
  }
  const fetchOriginal = window.fetch;
  if (fetchOriginal) window.fetch = async function(input, init) {
    const response = await fetchOriginal.call(this, input, init);
    const url = typeof input === 'string' ? input : input?.url;
    if (!state.enabled || !response.ok || !url) return response;
    let endpoint; try { endpoint = new URL(url, location.href); } catch { return response; }
    if (!/(^|\.)youtube\.com$/.test(endpoint.hostname) || !/^\/youtubei\/v1\/(player|next|browse)$/.test(endpoint.pathname)) return response;
    try {
      const copy = response.clone(), text = await copy.text();
      if (!state.enabled || !/"(?:adPlacements|playerAds|adSlots)"\s*:/.test(text)) return response;
      const data = prune(originalParse(text)), headers = new Headers(response.headers);
      headers.delete('content-length'); headers.delete('content-encoding');
      const filtered = new Response(JSON.stringify(data), { status: response.status, statusText: response.statusText, headers });
      Object.defineProperty(filtered, 'url', { value: response.url });
      return filtered;
    } catch { return response; }
  };
  const skipper = createFunTubeAdSkipper({onSkipped: () => notify('skips')});
  function tick() { if (state.enabled) skipper.tick(); else skipper.restore(); }
  document.addEventListener('funtube-try-player-skip', () => {
    if (!state.enabled) return;
    const player = document.querySelector('#movie_player,.html5-video-player');
    if (player && (player.classList.contains('ad-showing') || player.classList.contains('ad-interrupting'))) {
      try { player.skipAd?.(); } catch {}
    }
  });
  const style = document.createElement('style'); style.textContent = 'ytd-ad-slot-renderer,ytm-ad-slot-renderer,ytd-display-ad-renderer,ytm-promoted-sparkles-web-renderer,#masthead-ad,#player-ads,.ytp-ad-overlay-container{display:none!important}';
  function mount() { if (!style.isConnected && document.documentElement) { style.disabled = !state.enabled; document.documentElement.appendChild(style); } }
  document.addEventListener('DOMContentLoaded', mount, { once: true }); mount();
  window.__funTube = { configure(preferences) {
    state.enabled = preferences.enabled === true; state.autoFullscreen = preferences.autoFullscreen === true;
    style.disabled = !state.enabled; if (!state.enabled) skipper.restore(); else tick();
  }};
  document.addEventListener('playing', event => {
    if (state.autoFullscreen && event.target instanceof HTMLVideoElement) try { event.target.webkitEnterFullscreen?.(); } catch {}
  }, true);
  document.addEventListener('webkitbeginfullscreen', () => notify('fullscreen', 1), true);
  document.addEventListener('webkitendfullscreen', () => notify('fullscreen', 0), true);
  document.addEventListener('yt-navigate-finish', tick);
  setInterval(tick, 500);
  notify('ready');
})();
