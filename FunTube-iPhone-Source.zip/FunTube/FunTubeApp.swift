import SwiftUI

@main
@MainActor
struct FunTubeApp: App {
    @StateObject private var browser = FunTubeBrowser()
    var body: some Scene {
        WindowGroup { FunTubeView(browser: browser) }
    }
}
