using System; using System.IO; using System.Diagnostics; using System.Drawing; using System.Windows.Forms;
class FunTubeIPhoneSetup {
 [STAThread] static void Main() {
  Application.EnableVisualStyles(); Application.SetCompatibleTextRenderingDefault(false);
  var form=new Form {Text="FunTube for iPhone",ClientSize=new Size(640,590),StartPosition=FormStartPosition.CenterScreen,BackColor=Color.FromArgb(12,20,29),ForeColor=Color.White,Font=new Font("Segoe UI",10),FormBorderStyle=FormBorderStyle.FixedDialog,MaximizeBox=false};
  AddText(form,"FunTube for iPhone",24,22,592,44,22,Color.FromArgb(110,233,204));
  AddText(form,"Free installation with your Apple Account",24,72,590,28,12,Color.LightGray);
  string ipa=FindIpa();
  AddText(form,ipa==null?"iPhone app file not found. A successful iPhone build is needed first.":"iPhone app file is ready. No paid developer membership is needed.",24,112,588,46,10,ipa==null?Color.SandyBrown:Color.FromArgb(110,233,204));
  AddText(form,"1  Get Sideloadly on this PC using its official download page.",24,177,590,34,11,Color.White);
  AddText(form,"2  Connect and unlock your iPhone by USB. Trust this computer when asked.",24,219,590,52,11,Color.White);
  AddText(form,"3  Open Sideloadly, drag in FunTube-unsigned.ipa, choose your phone and sign in with your own Apple Account. Turn on automatic refresh, then click Start.",24,279,590,77,11,Color.White);
  AddText(form,"4  Follow the iPhone's Developer Mode / Trust prompts if shown. Then open FunTube from the Home Screen.",24,365,590,58,11,Color.White);
  AddText(form,"Free signatures last seven days. Automatic refresh needs this PC running and your phone connected by USB or available on the same Wi-Fi before expiry.",24,439,590,68,10,Color.LightGray);
  AddButton(form,"Get Sideloadly",24,527,180,()=>Open("https://sideloadly.io/"));
  var show=AddButton(form,"Show iPhone file",224,527,180,()=>{var p=FindIpa();if(p!=null)Process.Start(new ProcessStartInfo("explorer.exe","/select,\""+p+"\""){UseShellExecute=true});});show.Enabled=ipa!=null;
  AddButton(form,"Setup help",424,527,180,()=>Open("https://sideloadly.io/faq.html"));
  Application.Run(form);
 }
 static string FindIpa(){string root=AppDomain.CurrentDomain.BaseDirectory;foreach(var p in new[]{Path.Combine(root,"FunTube-unsigned.ipa"),Path.Combine(root,"..","build","FunTube-unsigned.ipa"),Path.Combine(root,"..","FunTube-unsigned.ipa")})if(File.Exists(p))return Path.GetFullPath(p);return null;}
 static void Open(string url){Process.Start(new ProcessStartInfo(url){UseShellExecute=true});}
 static void AddText(Form form,string text,int x,int y,int w,int h,int size,Color color){form.Controls.Add(new Label{Text=text,Location=new Point(x,y),Size=new Size(w,h),Font=new Font("Segoe UI",size),ForeColor=color});}
 static Button AddButton(Form form,string title,int x,int y,int w,Action action){var b=new Button{Text=title,Location=new Point(x,y),Size=new Size(w,40),BackColor=Color.FromArgb(32,61,66),ForeColor=Color.White,FlatStyle=FlatStyle.Flat};b.Click+=(s,e)=>{try{action();}catch(Exception error){MessageBox.Show(form,error.Message,"FunTube setup");}};form.Controls.Add(b);return b;}
}
