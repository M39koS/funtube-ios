import XCTest
import WebKit

@MainActor
final class FilterTests: XCTestCase {
    func testNetworkRulesCompileInWebKit() async throws {
        let url = try XCTUnwrap(Bundle.main.url(forResource: "blocker-rules", withExtension: "json"))
        let source = try String(contentsOf: url, encoding: .utf8)
        let list: WKContentRuleList = try await withCheckedThrowingContinuation { continuation in
            WKContentRuleListStore.default().compileContentRuleList(forIdentifier: "funtube-test", encodedContentRuleList: source) { list, error in
                if let list { continuation.resume(returning: list) }
                else { continuation.resume(throwing: error ?? NSError(domain: "Test", code: 1)) }
            }
        }
        XCTAssertEqual(list.identifier, "funtube-test")
    }

    func testPlayerDataFiltersRunInsideWebKit() async throws {
        let config = WKWebViewConfiguration()
        var script = "window.__funTubePreferences={enabled:true,autoFullscreen:false};"
        for name in ["ad-skipper", "player-filter"] {
            let url = try XCTUnwrap(Bundle.main.url(forResource: name, withExtension: "js"))
            script += "\n" + (try String(contentsOf: url, encoding: .utf8))
        }
        config.userContentController.addUserScript(WKUserScript(source: script, injectionTime: .atDocumentStart, forMainFrameOnly: true))
        let webView = WKWebView(frame: .zero, configuration: config)
        let ready = NavigationReady()
        webView.navigationDelegate = ready
        webView.loadHTMLString("<html><head><title>Filter fixture</title></head><body></body></html>", baseURL: URL(string: "https://www.youtube.com/funtube-test/"))
        await fulfillment(of: [ready.loaded], timeout: 20)
        let result = try await webView.evaluateJavaScript("""
        (()=>{
          const value=JSON.parse('{"videoDetails":{"videoId":"dQw4w9WgXcQ"},"adPlacements":[{"ad":1}],"streamingData":{"formats":[{"url":"https://media.example/video"}]}}');
          return {removed:!('adPlacements' in value),video:value.videoDetails.videoId,media:value.streamingData.formats[0].url};
        })()
        """) as? [String: Any]
        XCTAssertEqual(result?["removed"] as? Bool, true)
        XCTAssertEqual(result?["video"] as? String, "dQw4w9WgXcQ")
        XCTAssertEqual(result?["media"] as? String, "https://media.example/video")
        webView.stopLoading()
    }
}

@MainActor
private final class NavigationReady: NSObject, WKNavigationDelegate {
    let loaded = XCTestExpectation(description: "Fixture loaded in WebKit")
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) { loaded.fulfill() }
}
