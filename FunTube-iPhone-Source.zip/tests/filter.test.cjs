const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const source=fs.readFileSync(path.join(__dirname,'../FunTube/Resources/player-filter.js'),'utf8');
function fixture({enabled=true,hostname='m.youtube.com',fetcher=async()=>new Response('{}')}={}){
 const messages=[],styles=[];
 const context=vm.createContext({location:{hostname,href:'https://'+hostname+'/watch?v=dQw4w9WgXcQ'},URL,Headers,Response,performance,
  createFunTubeAdSkipper:()=>({tick(){},restore(){}}),setInterval(){},
  document:{createElement:()=>({isConnected:false}),documentElement:{appendChild:element=>{element.isConnected=true;styles.push(element);}},addEventListener(){}},
  HTMLVideoElement:class{},fetch:fetcher,webkit:{messageHandlers:{funTube:{postMessage:value=>messages.push(value)}}},__funTubePreferences:{enabled,autoFullscreen:false}});
 vm.runInContext('window=globalThis;',context);vm.runInContext(source,context);
 return {run:code=>vm.runInContext(code,context),messages,styles};
}
test('Player ads are pruned while real video metadata and stream URLs remain intact',()=>{
 const f=fixture();const result=f.run(`JSON.stringify(JSON.parse('{"videoDetails":{"videoId":"abc"},"playerAds":[{"x":1}],"adPlacements":[{},{}],"streamingData":{"url":"https://media.example/video"}}'))`);
 assert.deepEqual(JSON.parse(result),{videoDetails:{videoId:'abc'},streamingData:{url:'https://media.example/video'}});
 assert.equal(f.messages.filter(m=>m.type==='placements').reduce((n,m)=>n+m.count,0),3);
});
test('Unrelated JSON and custom revivers retain their original semantics',()=>{
 const f=fixture();assert.equal(f.run(`JSON.parse('{"adSlots":[1],"description":"ordinary data"}').adSlots.length`),1);
 assert.equal(f.run(`JSON.parse('{"videoDetails":{},"adSlots":[1]}',(k,v)=>v).adSlots.length`),1);
});
test('Initial player response assignments are filtered before the page uses them',()=>{
 const f=fixture();assert.equal(f.run(`window.ytInitialPlayerResponse={videoDetails:{videoId:'abc'},adSlots:[{}]};'adSlots' in window.ytInitialPlayerResponse`),false);
});
test('Protection off is respected from document start and can be enabled again',()=>{
 const f=fixture({enabled:false});assert.equal(f.run(`JSON.parse('{"videoDetails":{},"adSlots":[1]}').adSlots.length`),1);assert(f.styles[0].disabled);
 f.run('window.__funTube.configure({enabled:true,autoFullscreen:false})');assert(!f.styles[0].disabled);assert.equal(f.run(`'adSlots' in JSON.parse('{"videoDetails":{},"adSlots":[1]}')`),false);
});
test('YouTube API responses are pruned without losing status or media data',async()=>{
 const f=fixture({fetcher:async()=>new Response('{"contents":{"adSlots":[{}]},"streamingData":{"url":"keep"}}',{status:200,headers:{'content-type':'application/json'}})});
 const response=await f.run(`window.fetch('/youtubei/v1/player')`);assert.equal(response.status,200);assert.deepEqual(await response.json(),{contents:{},streamingData:{url:'keep'}});
});
test('Cross-origin responses and Google account pages are not modified',async()=>{
 const f=fixture({fetcher:async()=>new Response('{"videoDetails":{},"adSlots":[1]}')});const response=await f.run(`window.fetch('https://accounts.google.com/youtubei/v1/player')`);assert.equal((await response.json()).adSlots.length,1);
 const account=fixture({hostname:'accounts.google.com'});assert.equal(account.run('typeof window.__funTube'),'undefined');assert.equal(account.messages.length,0);
});
test('Malformed API data is returned intact instead of breaking playback',async()=>{
 const f=fixture({fetcher:async()=>new Response('{"adSlots":broken')});const response=await f.run(`window.fetch('/youtubei/v1/player')`);assert.equal(await response.text(),'{"adSlots":broken');
});
test('Network rules block known ad hosts without matching video streams or login',()=>{
 const rules=JSON.parse(fs.readFileSync(path.join(__dirname,'../FunTube/Resources/blocker-rules.json'))),blocked=url=>rules.some(r=>new RegExp(r.trigger['url-filter']).test(url));
 for(const url of ['https://googleads.g.doubleclick.net/pagead','https://ads.youtube.com/a','https://pagead2.googlesyndication.com/a'])assert(blocked(url),url);
 for(const url of ['https://rr1---sn.googlevideo.com/videoplayback?id=abc','https://m.youtube.com/watch?v=abc','https://accounts.google.com/ServiceLogin','https://notdoubleclick.net/a'])assert(!blocked(url),url);
});

test("WebKit patterns avoid unsupported alternation",()=>{const rules=JSON.parse(fs.readFileSync(path.join(__dirname,"../FunTube/Resources/blocker-rules.json")));for(const rule of rules)assert(!rule.trigger["url-filter"].includes("|"));});
