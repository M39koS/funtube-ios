"""Generate a minimal Xcode project using only Python's standard library."""
from pathlib import Path
import hashlib, json, plistlib

root = Path(__file__).resolve().parent.parent
objects = {}
def ref(name): return hashlib.sha256(name.encode()).hexdigest()[:24].upper()
def obj(object_key, isa, **values):
    key = ref(object_key); objects[key] = {'isa': isa, **values}; return key
def configurations(name, settings):
    result = []
    for mode in ['Debug', 'Release']:
        result.append(obj(name+mode, 'XCBuildConfiguration', name=mode, buildSettings={**settings, 'SWIFT_OPTIMIZATION_LEVEL': '-Onone' if mode == 'Debug' else '-O'}))
    return obj(name+'configs', 'XCConfigurationList', buildConfigurations=result, defaultConfigurationIsVisible=0, defaultConfigurationName='Release')

project_settings = {'IPHONEOS_DEPLOYMENT_TARGET': '16.0', 'SDKROOT': 'iphoneos', 'SWIFT_VERSION': '5.0', 'CLANG_ENABLE_MODULES': 'YES', 'ENABLE_USER_SCRIPT_SANDBOXING': 'YES'}
sources, resources, app_files = [], [], []
for file in sorted((root/'FunTube').glob('*.swift')):
    item = obj(str(file.relative_to(root)), 'PBXFileReference', lastKnownFileType='sourcecode.swift', path=file.name, sourceTree='<group>')
    app_files.append(item); sources.append(obj(str(file)+'build', 'PBXBuildFile', fileRef=item))
resource_files = []
for file in sorted((root/'FunTube/Resources').glob('*')):
    types = {'.js': 'sourcecode.javascript', '.json': 'text.json'}
    item = obj(str(file.relative_to(root)), 'PBXFileReference', lastKnownFileType=types.get(file.suffix, 'text'), path=file.name, sourceTree='<group>')
    resource_files.append(item); resources.append(obj(str(file)+'build', 'PBXBuildFile', fileRef=item))
assets = obj('assets', 'PBXFileReference', lastKnownFileType='folder.assetcatalog', path='Assets.xcassets', sourceTree='<group>')
app_files.append(assets); resources.append(obj('assetsBuild', 'PBXBuildFile', fileRef=assets))
resource_group = obj('resourcesGroup', 'PBXGroup', path='Resources', sourceTree='<group>', children=resource_files)
app_group = obj('appGroup', 'PBXGroup', path='FunTube', sourceTree='<group>', children=app_files+[resource_group])
app_product = obj('appProduct', 'PBXFileReference', explicitFileType='wrapper.application', path='FunTube.app', sourceTree='BUILT_PRODUCTS_DIR')
test_product = obj('testProduct', 'PBXFileReference', explicitFileType='wrapper.cfbundle', path='FunTubeTests.xctest', sourceTree='BUILT_PRODUCTS_DIR')
app_settings = {
    'PRODUCT_BUNDLE_IDENTIFIER': 'com.andre.funtube.mobile', 'PRODUCT_NAME': 'FunTube',
    'INFOPLIST_FILE': 'FunTube/Info.plist', 'TARGETED_DEVICE_FAMILY': '1,2',
    'CURRENT_PROJECT_VERSION': '1', 'MARKETING_VERSION': '0.1.0', 'CODE_SIGN_STYLE': 'Automatic',
    'ASSETCATALOG_COMPILER_APPICON_NAME': 'AppIcon', 'LD_RUNPATH_SEARCH_PATHS': ['$(inherited)', '@executable_path/Frameworks'],
    'GENERATE_INFOPLIST_FILE': 'NO', 'SWIFT_EMIT_LOC_STRINGS': 'NO'
}
app_target = obj('appTarget', 'PBXNativeTarget', name='FunTube', productName='FunTube', productReference=app_product,
    productType='com.apple.product-type.application', buildConfigurationList=configurations('app', app_settings), dependencies=[],
    buildPhases=[obj('appSources', 'PBXSourcesBuildPhase', buildActionMask=2147483647, files=sources, runOnlyForDeploymentPostprocessing=0),
                 obj('appResources', 'PBXResourcesBuildPhase', buildActionMask=2147483647, files=resources, runOnlyForDeploymentPostprocessing=0),
                 obj('appFrameworks', 'PBXFrameworksBuildPhase', buildActionMask=2147483647, files=[], runOnlyForDeploymentPostprocessing=0)])
test_file = obj('testFile', 'PBXFileReference', lastKnownFileType='sourcecode.swift', path='FilterTests.swift', sourceTree='<group>')
test_group = obj('testGroup', 'PBXGroup', path='FunTubeTests', sourceTree='<group>', children=[test_file])
proxy = obj('proxy', 'PBXContainerItemProxy', containerPortal=ref('project'), proxyType=1, remoteGlobalIDString=app_target, remoteInfo='FunTube')
dependency = obj('testDependency', 'PBXTargetDependency', target=app_target, targetProxy=proxy)
test_target = obj('testTarget', 'PBXNativeTarget', name='FunTubeTests', productName='FunTubeTests', productReference=test_product,
    productType='com.apple.product-type.bundle.unit-test', dependencies=[dependency],
    buildConfigurationList=configurations('test', {'PRODUCT_BUNDLE_IDENTIFIER': 'com.andre.funtube.mobile.tests', 'PRODUCT_NAME': '$(TARGET_NAME)', 'GENERATE_INFOPLIST_FILE': 'YES', 'TEST_HOST': '$(BUILT_PRODUCTS_DIR)/FunTube.app/$(BUNDLE_EXECUTABLE_FOLDER_PATH)/FunTube', 'BUNDLE_LOADER': '$(TEST_HOST)', 'TARGETED_DEVICE_FAMILY': '1,2', 'LD_RUNPATH_SEARCH_PATHS': ['$(inherited)', '@executable_path/Frameworks', '@loader_path/Frameworks']}),
    buildPhases=[obj('testSources', 'PBXSourcesBuildPhase', buildActionMask=2147483647, files=[obj('testBuild', 'PBXBuildFile', fileRef=test_file)], runOnlyForDeploymentPostprocessing=0), obj('testFrameworks', 'PBXFrameworksBuildPhase', buildActionMask=2147483647, files=[], runOnlyForDeploymentPostprocessing=0)])
products = obj('products', 'PBXGroup', name='Products', sourceTree='<group>', children=[app_product, test_product])
group = obj('mainGroup', 'PBXGroup', sourceTree='<group>', children=[app_group, test_group, products])
project = obj('project', 'PBXProject', objectVersion=56, attributes={'LastUpgradeCheck': '1600', 'BuildIndependentTargetsInParallel': 'YES'}, buildConfigurationList=configurations('project', project_settings), compatibilityVersion='Xcode 14.0', developmentRegion='en', hasScannedForEncodings=0, knownRegions=['en', 'Base'], mainGroup=group, productRefGroup=products, projectDirPath='', projectRoot='', targets=[app_target, test_target])

def render(value, indent=0):
    if isinstance(value, dict): return '{\n'+''.join('\t'*(indent+1)+json.dumps(k)+' = '+render(v, indent+1)+';\n' for k,v in value.items())+'\t'*indent+'}'
    if isinstance(value, list): return '('+', '.join(render(v, indent) for v in value)+')'
    return str(value) if isinstance(value, int) else json.dumps(value)
folder=root/'FunTube.xcodeproj';folder.mkdir(exist_ok=True)
(folder/'project.pbxproj').write_text('// !$*UTF8*$!\n'+render({'archiveVersion':1,'classes':{},'objectVersion':56,'objects':objects,'rootObject':project})+'\n')
scheme=folder/'xcshareddata/xcschemes';scheme.mkdir(parents=True,exist_ok=True)
(scheme/'FunTube.xcscheme').write_text(f'''<?xml version="1.0" encoding="UTF-8"?>
<Scheme LastUpgradeVersion="1600" version="1.3">
<BuildAction parallelizeBuildables="YES" buildImplicitDependencies="YES"><BuildActionEntries><BuildActionEntry buildForTesting="YES" buildForRunning="YES" buildForProfiling="YES" buildForArchiving="YES" buildForAnalyzing="YES"><BuildableReference BuildableIdentifier="primary" BlueprintIdentifier="{app_target}" BuildableName="FunTube.app" BlueprintName="FunTube" ReferencedContainer="container:FunTube.xcodeproj"/></BuildActionEntry></BuildActionEntries></BuildAction>
<TestAction buildConfiguration="Debug" selectedDebuggerIdentifier="Xcode.DebuggerFoundation.Debugger.LLDB" selectedLauncherIdentifier="Xcode.IDEFoundation.Launcher.LLDB" shouldUseLaunchSchemeArgsEnv="YES"><Testables><TestableReference skipped="NO"><BuildableReference BuildableIdentifier="primary" BlueprintIdentifier="{test_target}" BuildableName="FunTubeTests.xctest" BlueprintName="FunTubeTests" ReferencedContainer="container:FunTube.xcodeproj"/></TestableReference></Testables></TestAction>
<LaunchAction buildConfiguration="Debug" selectedDebuggerIdentifier="Xcode.DebuggerFoundation.Debugger.LLDB" selectedLauncherIdentifier="Xcode.IDEFoundation.Launcher.LLDB" launchStyle="0" useCustomWorkingDirectory="NO" ignoresPersistentStateOnLaunch="NO" debugDocumentVersioning="YES" debugServiceExtension="internal" allowLocationSimulation="YES"><BuildableProductRunnable runnableDebuggingMode="0"><BuildableReference BuildableIdentifier="primary" BlueprintIdentifier="{app_target}" BuildableName="FunTube.app" BlueprintName="FunTube" ReferencedContainer="container:FunTube.xcodeproj"/></BuildableProductRunnable></LaunchAction>
<ProfileAction buildConfiguration="Release" shouldUseLaunchSchemeArgsEnv="YES" savedToolIdentifier="" useCustomWorkingDirectory="NO" debugDocumentVersioning="YES"/>
<AnalyzeAction buildConfiguration="Debug"/><ArchiveAction buildConfiguration="Release" revealArchiveInOrganizer="YES"/>
</Scheme>''')
info={'CFBundleDevelopmentRegion':'en','CFBundleDisplayName':'FunTube','CFBundleExecutable':'$(EXECUTABLE_NAME)','CFBundleIdentifier':'$(PRODUCT_BUNDLE_IDENTIFIER)','CFBundleInfoDictionaryVersion':'6.0','CFBundleName':'$(PRODUCT_NAME)','CFBundlePackageType':'APPL','CFBundleShortVersionString':'$(MARKETING_VERSION)','CFBundleVersion':'$(CURRENT_PROJECT_VERSION)','LSRequiresIPhoneOS':True,'UILaunchScreen':{},'UIApplicationSceneManifest':{'UIApplicationSupportsMultipleScenes':False},'UISupportedInterfaceOrientations':['UIInterfaceOrientationPortrait','UIInterfaceOrientationLandscapeLeft','UIInterfaceOrientationLandscapeRight'],'UISupportedInterfaceOrientations~ipad':['UIInterfaceOrientationPortrait','UIInterfaceOrientationPortraitUpsideDown','UIInterfaceOrientationLandscapeLeft','UIInterfaceOrientationLandscapeRight']}
with (root/'FunTube/Info.plist').open('wb') as file:plistlib.dump(info,file)
print('Generated FunTube app and WebKit test targets.')
