#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
python3 scripts/make-project.py
mkdir -p FunTube/Assets.xcassets/AppIcon.appiconset build
swift scripts/make-icon.swift FunTube/Assets.xcassets/AppIcon.appiconset/icon.png
python3 - <<'PY'
import json
from pathlib import Path
root=Path('FunTube/Assets.xcassets')
(root/'Contents.json').write_text(json.dumps({'info':{'author':'xcode','version':1}}))
(root/'AppIcon.appiconset/Contents.json').write_text(json.dumps({'images':[{'filename':'icon.png','idiom':'universal','platform':'ios','size':'1024x1024'}],'info':{'author':'xcode','version':1}}))
PY
xcodebuild -project FunTube.xcodeproj -scheme FunTube -configuration Release -sdk iphoneos -destination 'generic/platform=iOS' -derivedDataPath build/device CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO build
mkdir -p build/package/Payload
ditto build/device/Build/Products/Release-iphoneos/FunTube.app build/package/Payload/FunTube.app
(cd build/package && zip -qr ../FunTube-unsigned.ipa Payload)
shasum -a 256 build/FunTube-unsigned.ipa > build/SHA256.txt
echo 'Built an unsigned IPA. Install and sign it using your own free Apple Account in Sideloadly.'
