import AppKit

let destination = CommandLine.arguments[1]
let size = NSSize(width: 1024, height: 1024)
let image = NSImage(size: size)
image.lockFocus()
NSColor(calibratedRed: 0.055, green: 0.105, blue: 0.13, alpha: 1).setFill()
NSBezierPath(rect: NSRect(origin: .zero, size: size)).fill()
NSColor(calibratedRed: 0.43, green: 0.91, blue: 0.80, alpha: 1).setFill()
NSBezierPath(roundedRect: NSRect(x: 180, y: 245, width: 664, height: 534), xRadius: 130, yRadius: 130).fill()
let play = NSBezierPath()
play.move(to: NSPoint(x: 430, y: 355)); play.line(to: NSPoint(x: 430, y: 670)); play.line(to: NSPoint(x: 670, y: 512)); play.close()
NSColor(calibratedRed: 0.055, green: 0.105, blue: 0.13, alpha: 1).setFill(); play.fill()
image.unlockFocus()
guard let tiff = image.tiffRepresentation, let bitmap = NSBitmapImageRep(data: tiff), let data = bitmap.representation(using: .png, properties: [:]) else { fatalError("Could not render icon") }
try data.write(to: URL(fileURLWithPath: destination))
