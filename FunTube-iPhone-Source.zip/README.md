# FunTube for iPhone

Native SwiftUI/WKWebView app with network filters and player scripts bundled
inside the app. It does not require a Safari extension or a separate blocker
on the phone. This repository contains no account cookies or signing keys.

## Build without a paid Apple membership

The **Build FunTube for free sideloading** GitHub Actions workflow uses a
standard macOS runner to compile an unsigned iPhone IPA and run WebKit simulator
tests. Standard hosted runners are free for public repositories. The workflow
does not use Apple credentials or purchase build services. A successful build
publishes the **FunTube-iPhone** artifact for seven days.

Download and extract that artifact. Run `windows/FunTube-iPhone-Setup.exe`, or
follow `windows/INSTALL.txt`. Sideloadly on Windows signs and installs the IPA
using your own free Apple Account. The Apple profile expires after seven days;
automatic refresh needs your PC running and the paired phone reachable before
expiry. This route is not an App Store release or permanent unsigned install.

## Included behavior

- Native navigation, six themes, video fullscreen and an optional automatic
  fullscreen request (subject to iOS gesture permissions).
- Persistent in-app website data and cookies using WebKit's standard store.
- Network filtering is compiled before the first YouTube navigation. Startup
  failure is displayed instead of silently opening an unfiltered page.
- Player-data filtering and the desktop FunTube Skip handler are bundled
  locally. The skipper does not seek or accelerate an ad, avoiding completion
  timers stuck at their final second. Sponsored cards preserve the content video.
- Activity counts distinguish removed player-data entries from confirmed
  auto-skips. They do not claim to count impressions or all blocked requests.
- No forced playback recovery or background update downloads.

## Verification limits

Successful simulator checks verify compilation, WebKit rule compilation and
controlled player fixtures. They do not establish universal YouTube ad blocking.
Real playback and blocking need physical iPhone verification. Google may reject
embedded-browser login; native Google sign-in has not been verified. Do not
describe this as a proven replacement for the Windows release before device
testing. The existing FunTube Pocket website is separate and unchanged.

## Local checks

`node --test tests/filter.test.cjs` runs the filtering logic checks without
dependencies. On a Mac with Xcode, run `bash scripts/build-ios.sh`. The project
generator uses Python's standard library. `scripts/make-icon.swift` draws the
app icon from native shapes. `windows/Setup.cs` builds with the Windows .NET
Framework C# compiler and opens only official setup pages or the local IPA.

Original FunTube code is MIT licensed. See LICENSE and PROVENANCE.json.
